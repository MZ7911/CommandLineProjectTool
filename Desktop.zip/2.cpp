#include <bits/stdtr1c++.h>
using namespace std;

class Asker {
public:
	static ostream & ask(size_t minLen, string message, ostream & os) {
		return os << setw(minLen) << left << message;
	}
	static string get(size_t minLen, string message) {
		ostringstream stream;
		stream << setw(minLen) << left << message;
		return stream.str();
	}
};

int main() {
	{ Asker::ask(20, "ENTER SOMETHING:", cout); string line; getline(cin, line); }
	{ cout << Asker::get(20, "ENTER SOMETHING:"); string line; getline(cin, line); }
}
