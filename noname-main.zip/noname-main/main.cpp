#include <iostream>
#include <string>
#include <sstream>
#include <map>
#include <iomanip>
using namespace std;

class Asker {
public:
	static ostream & ask(size_t minLen, string message, ostream & os) {
		return os << setw(minLen) << left << message;
	}
	static string get(size_t minLen, string message) {
		ostringstream stream;
		stream << setw(minLen) << left << message;
		return stream.str();
	}
};

#include "console.h"

int getInteger(string prompt = "") {
	
    int value;
    
    while (true) {
        cout << prompt;
        string line;
        getline(std::cin, line);
        
        istringstream stream(line);
        stream >> value;
        if (!stream.fail() && stream.eof()) {
            break;
        }
        
        cout << "Illegal integer format. Please try again." << endl;
    }
    
    return value;
    
}

int main() {
	
    while (true) {
    	
        int nData = getInteger(Asker::get(25, "<# nData $>"));
        map<int, int> data;
        for (int i = 0; i < nData; i++) {
            int key = getInteger(Asker::get(25, "   <# key" + to_string(i) + " $> "));
            int value = getInteger(Asker::get(25, "   <# value" + to_string(i) + " $> "));
            data[key] = value;
        }
        
        cout << endl << string(10, '-') << endl;
        for (pair<int, int> e : data) {
            cout << setw(3) << e.first << " | " << string(e.second, '*') << endl;
        }
        cout << string(10, '-') << endl;
        
        cout << "<* Quit? (Q)$> ";
        string str;
        getline(cin, str);
        if (str == "q" || str == "Q") {
            break;
        }
        
        WINDOWS_clearScreen();
        
    }
    
    return 0;
    
}
