#include <cassert>
#include <iostream>
#include <iomanip>
#include <typeinfo>
#include "Asker.h"

#define printInfo(asker) \
std::cout << " _____________________________________________________________" << std::endl; \
std::cout << "| " << #asker << std::endl; \
std::cout << "| " << ".leftBrace { " << "std::string" << " \"" << asker.getLeftBrace() << "\" }" << std::endl; \
std::cout << "| " << ".rightBrace { " << "std::string" << " \"" << asker.getRightBrace() << "\" }" << std::endl; \
std::cout << "| " << ".prompt { " << "std::string" << " \"" << asker.getPrompt() << "\" }" << std::endl; \
std::cout << "| " << ".promptInBrace { " << "bool" << " \"" << asker.getPromptInBrace() << "\" }" << std::endl;




int main() {
    Asker asker1;
    printInfo(asker1)
}
