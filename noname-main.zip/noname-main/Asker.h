#ifndef ASKER_H
#define ASKER_H


#include <string>


class Asker {
    
public:
    
    Asker() :
        leftBrace(""), rightBrace(""), prompt("?"), promptInBrace(true) {

    }

    Asker(std::string leftBrace, std::string rightBrace) :
        leftBrace(leftBrace), rightBrace(rightBrace) {

    }

    Asker(std::string prompt, bool promptInBrace) :
        prompt(prompt), promptInBrace(promptInBrace) {

    }

    Asker(std::string leftBrace, std::string rightBrace, std::string prompt, bool promptInBrace) :
        leftBrace(leftBrace), rightBrace(rightBrace), prompt(prompt), promptInBrace(promptInBrace) {

    }

    std::string getLeftBrace() const {
        return leftBrace;
    }

    std::string getRightBrace() const {
        return rightBrace;
    }

    std::string getPrompt() const {
        return prompt;
    }

    bool getPromptInBrace() const {
        return promptInBrace;
    }
    
private:
    
    std::string leftBrace;
    std::string rightBrace;
    
    std::string prompt;
    bool promptInBrace;

};


#endif //ASKER_H
